HISTFILE=~/.zsh_history; HISTSIZE=5000; SAVEHIST=5000
autoload -Uz compinit && compinit
source /usr/share/zsh/plugins/zsh-autosuggestions/zsh-autosuggestions.zsh
source /usr/share/zsh/plugins/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh
eval "$(starship init zsh)"

alias ll='eza -l --icons'
alias la='eza -la --icons'
alias cat='bat --paging=never'
alias soita='mpv --no-video'
alias nuotti='musescore'
alias paivita='sudo pacman -Syu'
alias flyygeli-audio='pw-top'
alias vireet='pw-metadata -n settings 0 clock.force-quantum'
